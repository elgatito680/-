import random
from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.properties import StringProperty, ListProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.animation import Animation
from kivy.metrics import dp
from quest_live_hub.message_store import MessageStore
from quest_live_hub.chat_message import ChatMessage
from quest_live_hub.controller import ChatController

KV = r'''
#:import dp kivy.metrics.dp
<ChatCard@BoxLayout>:
    orientation: 'vertical'
    size_hint_y: None
    height: dp(62)
    padding: dp(10)
    spacing: dp(3)
    canvas.before:
        Color:
            rgba: (0.10, 0.15, 0.25, 0.94)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(12)]
    Label:
        text: root.author_line
        color: (0.45, 0.82, 1, 1)
        bold: True
        font_size: '13sp'
        halign: 'left'
        text_size: self.size
    Label:
        text: root.message_text
        color: (0.94, 0.96, 1, 1)
        font_size: '14sp'
        halign: 'left'
        valign: 'middle'
        text_size: self.width, None
        size_hint_y: None
        height: self.texture_size[1]
BoxLayout:
    orientation: 'vertical'
    padding: dp(14)
    spacing: dp(10)
    canvas.before:
        Color:
            rgba: (0.035, 0.055, 0.105, 1)
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        size_hint_y: None
        height: dp(48)
        Label:
            text: '[b]QUEST LIVE HUB[/b]  [color=55caff]●[/color]'
            markup: True
            font_size: '20sp'
            halign: 'left'
        Label:
            text: 'QUEST 2 · 3 · 3S'
            color: (0.55, 0.68, 0.9, 1)
            size_hint_x: .55
    BoxLayout:
        size_hint_y: None
        height: dp(38)
        Label:
            text: app.status
            color: (0.55, 0.85, 1, 1)
            halign: 'left'
    BoxLayout:
        size_hint_y: None
        height: dp(42)
        spacing: dp(6)
        Spinner:
            id: provider
            text: 'Demo'
            values: ['Demo', 'Twitch', 'YouTube', 'TikTok (not enabled)']
        Button:
            text: 'DEMO'
            on_release: app.start_demo()
        Button:
            text: 'STOP'
            on_release: app.stop_all()
    BoxLayout:
        id: credential_area
        size_hint_y: None
        height: dp(126)
        spacing: dp(5)
        orientation: 'vertical'
        TextInput:
            id: channel
            hint_text: 'Twitch channel / YouTube liveChatId'
            multiline: False
            size_hint_y: .34
        TextInput:
            id: username
            hint_text: 'Twitch account username (Twitch only)'
            multiline: False
            size_hint_y: .30
        TextInput:
            id: token
            hint_text: 'OAuth access token (session only)'
            password: True
            multiline: False
            size_hint_y: .36
    BoxLayout:
        size_hint_y: None
        height: dp(40)
        spacing: dp(6)
        Button:
            text: 'CONNECT'
            on_release: app.connect_selected()
        Button:
            text: 'WRIST LAYOUT'
            on_release: app.toggle_wrist()
    BoxLayout:
        id: chat_header
        size_hint_y: None
        height: dp(32)
        Label:
            text: '[b]LIVE CHAT[/b]'
            markup: True
            halign: 'left'
        Label:
            text: str(len(app.messages)) + ' / 80'
            color: (0.55, 0.68, 0.9, 1)
    ScrollView:
        do_scroll_x: False
        GridLayout:
            id: chat_list
            cols: 1
            spacing: dp(7)
            size_hint_y: None
            height: self.minimum_height
    Label:
        size_hint_y: None
        height: dp(20)
        text: 'Soft neon interface · session-only credentials'
        color: (0.42, 0.52, 0.7, 1)
        font_size: '10sp'
'''

class QuestLiveHubApp(App):
    status = StringProperty("Ready · choose Demo or connect a provider")
    messages = ListProperty([])

    def build(self):
        self.store = MessageStore(80)
        self.controller = ChatController(self._receive_message, self._set_status)
        self.root = Builder.load_string(KV)
        self.wrist_mode = False
        return self.root

    def _set_status(self, text):
        Clock.schedule_once(lambda _dt: setattr(self, "status", str(text)[:140]), 0)

    def _receive_message(self, message):
        self.store.add(message)
        Clock.schedule_once(lambda _dt: self._refresh_chat(), 0)

    def _refresh_chat(self):
        self.messages = self.store.snapshot()
        grid = self.root.ids.chat_list
        grid.clear_widgets()
        for msg in self.messages:
            card = BoxLayout(orientation="vertical", size_hint_y=None,
                             height=dp(62), padding=dp(9), spacing=dp(2))
            from kivy.uix.label import Label
            from kivy.graphics import Color, RoundedRectangle
            with card.canvas.before:
                Color(0.10, 0.15, 0.25, 0.96)
                card.bg = RoundedRectangle(pos=card.pos, size=card.size,
                                           radius=[dp(12)])
            card.bind(pos=lambda inst, val: setattr(inst.bg, "pos", val),
                      size=lambda inst, val: setattr(inst.bg, "size", val))
            author = Label(text=f"[b]{msg.platform}[/b]  {msg.author}",
                           markup=True, color=(0.45, 0.82, 1, 1),
                           font_size="12sp", halign="left", valign="middle",
                           size_hint_y=None, height=dp(20))
            body = Label(text=msg.text, color=(0.94, 0.96, 1, 1),
                         font_size="14sp", halign="left", valign="middle",
                         text_size=(self.root.width - dp(55), None),
                         size_hint_y=None, height=dp(30))
            card.add_widget(author)
            card.add_widget(body)
            card.opacity = 0
            grid.add_widget(card)
            Animation(opacity=1, duration=.18, t="out_quad").start(card)

    def start_demo(self):
        self.stop_all()
        self.status = "Demo chat running"
        self.demo_event = Clock.schedule_interval(self._demo_tick, 1.7)

    def _demo_tick(self, _dt):
        names = ["Nova", "PixelFox", "MikaVR", "CloudByte", "StarPlayer"]
        texts = ["Let's go!!", "Nice stream ✨", "GG", "Hello from Quest!",
                 "That was amazing", "W chat 💙"]
        self._receive_message(ChatMessage.create("Demo",
            random.choice(names), random.choice(texts)))

    def connect_selected(self):
        self.stop_all()
        provider = self.root.ids.provider.text
        channel = self.root.ids.channel.text.strip()
        token = self.root.ids.token.text.strip()
        if provider == "Twitch":
            self.controller.connect("Twitch", {"channel": channel, "username": self.root.ids.username.text.strip(), "token": token})
        elif provider == "YouTube":
            self.controller.connect("YouTube", {"live_chat_id": channel, "token": token})
        else:
            self.status = "Choose Twitch or YouTube. TikTok is not enabled in this build."

    def toggle_wrist(self):
        self.wrist_mode = not self.wrist_mode
        self.status = ("Compact wrist-style layout preview" if self.wrist_mode
                       else "Standard chat layout")
        self.root.padding = dp(5) if self.wrist_mode else dp(14)

    def stop_all(self):
        if hasattr(self, "demo_event"):
            self.demo_event.cancel()
        self.controller.disconnect()
        self.status = "Disconnected"

    def on_stop(self):
        self.controller.shutdown()

if __name__ == "__main__":
    QuestLiveHubApp().run()
