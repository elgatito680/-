import asyncio
import threading
from .providers.twitch_irc import TwitchIRCProvider
from .providers.youtube_live import YouTubeLiveProvider
from .providers.tiktok import TikTokLiveProvider

class ChatController:
    def __init__(self, on_message, on_status):
        self.on_message = on_message
        self.on_status = on_status
        self.loop = None
        self.thread = None
        self.provider = None
        self.future = None

    def _ensure_loop(self):
        if self.loop and self.loop.is_running():
            return
        ready = threading.Event()
        def worker():
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)
            ready.set()
            self.loop.run_forever()
            pending = asyncio.all_tasks(self.loop)
            for task in pending:
                task.cancel()
            self.loop.close()
        self.thread = threading.Thread(target=worker, daemon=True)
        self.thread.start()
        ready.wait(timeout=5)

    def connect(self, platform, values):
        self.disconnect()
        self._ensure_loop()
        callback = lambda message: self.on_message(message)
        status = lambda text: self.on_status(text)
        if platform == "Twitch":
            self.provider = TwitchIRCProvider(values.get("channel", ""), values.get("username", ""),
                values.get("token", ""), callback, status)
        elif platform == "YouTube":
            self.provider = YouTubeLiveProvider(values.get("live_chat_id", ""),
                values.get("token", ""), callback, status)
        else:
            self.provider = TikTokLiveProvider(callback, status)
        self.future = asyncio.run_coroutine_threadsafe(self.provider.run(), self.loop)
        def done(future):
            try:
                future.result()
            except Exception as exc:
                self.on_status(str(exc))
        self.future.add_done_callback(done)

    def disconnect(self):
        if self.provider and self.loop and self.loop.is_running():
            asyncio.run_coroutine_threadsafe(self.provider.close(), self.loop)
        self.provider = None
        self.on_status("Disconnected")

    def shutdown(self):
        self.disconnect()
        if self.loop and self.loop.is_running():
            self.loop.call_soon_threadsafe(self.loop.stop)
