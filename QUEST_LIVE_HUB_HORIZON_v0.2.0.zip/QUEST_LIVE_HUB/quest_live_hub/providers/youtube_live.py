import asyncio
import aiohttp
from .base import ChatProvider, ProviderError
from ..chat_message import ChatMessage

API = "https://www.googleapis.com/youtube/v3/liveChat/messages"

class YouTubeLiveProvider(ChatProvider):
    def __init__(self, live_chat_id, access_token, on_message, on_status):
        super().__init__(on_message, on_status)
        self.live_chat_id = live_chat_id.strip()
        self.access_token = access_token.strip()
        self.stopped = False

    async def run(self):
        if not self.live_chat_id or not self.access_token:
            raise ProviderError("YouTube liveChatId and OAuth access token are required.")
        headers = {"Authorization": f"Bearer {self.access_token}"}
        params = {"liveChatId": self.live_chat_id,
                  "part": "snippet,authorDetails", "maxResults": 200}
        self.on_status("YouTube: connecting…")
        timeout = aiohttp.ClientTimeout(total=25)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            self.on_status("YouTube: connected")
            while not self.stopped:
                async with session.get(API, headers=headers, params=params) as response:
                    if response.status == 401:
                        raise ProviderError("YouTube token expired or lacks permission.")
                    if response.status == 403:
                        raise ProviderError("YouTube API access or quota denied.")
                    if response.status == 404:
                        raise ProviderError("YouTube live chat was not found or is no longer live.")
                    if response.status >= 400:
                        raise ProviderError(f"YouTube API returned HTTP {response.status}.")
                    data = await response.json()
                for item in data.get("items", []):
                    snippet = item.get("snippet", {})
                    author = item.get("authorDetails", {}).get("displayName", "Unknown")
                    text = snippet.get("displayMessage", "")
                    if text:
                        self.on_message(ChatMessage.create("YouTube", author, text))
                params["pageToken"] = data.get("nextPageToken", "")
                delay = max(2.0, min(data.get("pollingIntervalMillis", 5000) / 1000, 30.0))
                await asyncio.sleep(delay)

    async def close(self):
        self.stopped = True
