from .base import ChatProvider, ProviderError

class TikTokLiveProvider(ChatProvider):
    async def run(self):
        raise ProviderError(
            "TikTok Live chat is not enabled: configure an approved official API "
            "integration before adding this provider. Unofficial scraping is not used."
        )

    async def close(self):
        return None
