from abc import ABC, abstractmethod

class ProviderError(Exception):
    pass

class ChatProvider(ABC):
    def __init__(self, on_message, on_status):
        self.on_message = on_message
        self.on_status = on_status
        self._task = None

    @abstractmethod
    async def run(self):
        raise NotImplementedError

    @abstractmethod
    async def close(self):
        raise NotImplementedError
