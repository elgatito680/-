import asyncio
import re
import websockets
from .base import ChatProvider, ProviderError
from ..chat_message import ChatMessage

TWITCH_IRC = "wss://irc-ws.chat.twitch.tv:443"

class TwitchIRCProvider(ChatProvider):
    def __init__(self, channel, username, oauth_token, on_message, on_status):
        super().__init__(on_message, on_status)
        self.channel = channel.strip().lstrip("#").lower()
        self.username = username.strip().lstrip("@").lower()
        self.token = oauth_token.strip()
        self.ws = None
        self.stopped = False

    async def run(self):
        if not self.channel or not self.username or not self.token:
            raise ProviderError("Twitch channel, account username and OAuth token are required.")
        token = self.token.removeprefix("oauth:")
        self.on_status("Twitch: connecting…")
        try:
            async with websockets.connect(TWITCH_IRC, ping_interval=30,
                                          close_timeout=3, max_size=2**18) as ws:
                self.ws = ws
                await ws.send(f"PASS oauth:{token}")
                await ws.send(f"NICK {self.username}")
                await ws.send(f"JOIN #{self.channel}")
                self.on_status(f"Twitch: connected to #{self.channel}")
                async for raw in ws:
                    if raw.startswith("PING"):
                        await ws.send("PONG :tmi.twitch.tv")
                        continue
                    match = re.match(r":([^!]+)!.* PRIVMSG #[^ ]+ :(.*)", raw)
                    if match:
                        self.on_message(ChatMessage.create("Twitch", match.group(1), match.group(2)))
        except Exception as exc:
            if not self.stopped:
                self.on_status(f"Twitch connection error: {type(exc).__name__}")
                raise ProviderError("Twitch connection failed. Check the token, channel and network.") from exc
        finally:
            self.ws = None

    async def close(self):
        self.stopped = True
        if self.ws:
            await self.ws.close()
