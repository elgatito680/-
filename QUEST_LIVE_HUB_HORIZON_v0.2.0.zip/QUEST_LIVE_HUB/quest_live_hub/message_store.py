from collections import deque
from threading import RLock

class MessageStore:
    def __init__(self, max_messages=80):
        self._items = deque(maxlen=max(10, min(int(max_messages), 250)))
        self._lock = RLock()

    def add(self, message):
        with self._lock:
            self._items.append(message)

    def snapshot(self):
        with self._lock:
            return list(self._items)

    def clear(self):
        with self._lock:
            self._items.clear()
