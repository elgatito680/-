from dataclasses import dataclass
from datetime import datetime, timezone

@dataclass(frozen=True, slots=True)
class ChatMessage:
    platform: str
    author: str
    text: str
    timestamp: str

    @classmethod
    def create(cls, platform: str, author: str, text: str):
        safe_author = str(author or "Unknown")[:48]
        safe_text = str(text or "")[:500]
        return cls(platform, safe_author, safe_text,
                   datetime.now(timezone.utc).isoformat(timespec="seconds"))
