[app]
title = QUEST LIVE HUB
package.name = questlivehub
package.domain = com.example
source.dir = .
source.include_exts = py,kv,png,jpg,atlas,json,md
version = 0.1.0
requirements = python3,kivy,websockets, aiohttp
orientation = landscape
fullscreen = 0
android.archs = arm64-v8a
android.api = 35
android.minapi = 29
android.ndk = 27c
android.permissions = INTERNET,ACCESS_NETWORK_STATE
android.extra_manifest_xml = src/android/extra_manifest.xml
android.extra_manifest_application_xml = src/android/extra_manifest_application.xml
# Horizon OS overlay launcher; deliberately do NOT request SYSTEM_ALERT_WINDOW.
android.allow_backup = false
android.private_storage = true
android.release_artifact = apk
p4a.bootstrap = sdl2
# No SYSTEM_ALERT_WINDOW permission: it is not an approved general-purpose VR overlay.
# No always-on background service is declared in this prototype.
[buildozer]
log_level = 2
warn_on_root = 1
