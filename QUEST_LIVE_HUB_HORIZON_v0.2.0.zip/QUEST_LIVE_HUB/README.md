# QUEST LIVE HUB — Android/Kivy starter project

A Python/Kivy Android application prototype for Meta Quest 2, Quest 3 and Quest 3S.
It provides an animated chat dashboard, a local demo feed, and connector modules for
Twitch IRC and YouTube Live Chat. TikTok Live is represented by an explicit
unsupported-provider adapter: this project does not scrape TikTok or use unofficial
endpoints.

## Important platform boundaries

- This project builds a **2D Android APK** using Kivy and python-for-android.
- The project now declares a Horizon OS 2D overlay-launcher alias. On supported
  Horizon OS versions, the user can launch QUEST LIVE HUB from the in-headset overlay
  launcher while an immersive app is running; Horizon OS presents it as a panel.
- This is not Android's generic `SYSTEM_ALERT_WINDOW` floating-window permission.
  Meta lists `SYSTEM_ALERT_WINDOW` as prohibited for Horizon OS Store submissions.
- The panel is a system-positioned 2D panel, not yet a wrist-anchored spatial panel.
  A true wrist anchor requires a dedicated immersive activity and spatial input/pose
  integration. The current project does not implement that part.
- A wrist-anchored panel needs a native immersive activity using Meta Spatial SDK /
  OpenXR input and pose APIs. The current app exposes a wrist-style compact chat layout
  as a UI prototype only; it is not spatially anchored to the user's wrist.
- Background chat operation after the app is closed is not promised by this starter.
  Android background execution on Horizon OS must be implemented and validated using
  permitted foreground-service patterns and current Meta requirements.
- No ADB is needed to run the app after it has been installed. Building the APK needs
  a Linux build environment (local Linux or CI). Installing a sideloaded APK may still
  require an approved installation path; this project does not bypass device security.

## Features

- Kivy interface with soft neon styling and animated message cards.
- Local demo mode for UI testing without platform credentials.
- Twitch chat connector using the Twitch IRC WebSocket endpoint.
- YouTube Live Chat polling connector using the official YouTube Data API.
- TikTok adapter that clearly reports that an approved official integration is needed.
- Bounded message queue to avoid unbounded memory growth.
- Credentials are session-only and are not written to disk.
- Reconnect/error handling and configurable message cap.

## Requirements

- Python 3.11 recommended for desktop preview.
- Android build: Linux x86_64, Java 17, Buildozer, Android SDK/NDK managed by
  python-for-android/Buildozer.
- Network access on the headset.
- Twitch: Twitch account OAuth token with chat read permission and the channel name.
- YouTube: OAuth access token with permission to read the live chat, plus `liveChatId`.
  For a production app, implement Google OAuth consent and refresh-token handling.
- TikTok: an approved, documented API/product integration must be available to your app.
  No unofficial scraping is included.

## Desktop preview

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements-desktop.txt
python main.py
```

Press **DEMO** to see sample messages. The desktop preview is useful for UI testing;
it is not a Quest overlay.

## Build Android APK

On Linux:

```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip setuptools wheel
pip install buildozer cython==0.29.36
buildozer android debug
```

The generated debug APK is normally under `bin/`.

For a repeatable cloud build, push this folder to a GitHub repository and run the
included `.github/workflows/android.yml` workflow. Download the APK artifact from
the completed workflow. A release APK must be signed with your own private signing
key; never commit that key or its passwords.

## Connecting providers

### Twitch

1. Register an application in the Twitch developer console.
2. Obtain a user access token with the minimum chat-reading scope required by the
   current Twitch documentation.
3. In the app, select Twitch, enter the channel name, the Twitch username associated with that token, and the OAuth token.
4. The token is kept in memory only and cleared when the app process exits.

This starter uses Twitch IRC over WebSocket for the chat transport. For a production
release, prefer the current Twitch EventSub chat flow and implement the OAuth flow
inside a registered application.

### YouTube

1. Create a Google Cloud project and enable YouTube Data API v3.
2. Configure OAuth consent and request the minimum read-only scope required.
3. Obtain an OAuth access token and the broadcast's `liveChatId`.
4. Enter both in the YouTube connection panel.

The connector honours the API's `pollingIntervalMillis` and `nextPageToken`.
The official API also documents `liveChatMessages.streamList` as the lower-latency
server-streaming option; this starter uses the simpler list/poll method.

### TikTok

TikTok Live chat is not enabled here. Do not paste credentials into third-party
"chat scraper" services. Add a connector only after obtaining an official,
documented integration and required permissions.

## Project layout

```text
QUEST_LIVE_HUB/
├── main.py
├── app.kv
├── buildozer.spec
├── requirements-desktop.txt
├── requirements-android.txt
├── README.md
├── .gitignore
├── .github/workflows/android.yml
└── quest_live_hub/
    ├── __init__.py
    ├── chat_message.py
    ├── message_store.py
    ├── controller.py
    └── providers/
        ├── __init__.py
        ├── base.py
        ├── twitch_irc.py
        ├── youtube_live.py
        └── tiktok.py
```

## Security notes

- Never commit OAuth tokens, API secrets, keystores, or passwords.
- Use a backend OAuth broker for a public production release; do not embed a client
  secret in an APK.
- Validate provider responses and keep the UI responsive.
- Review current platform terms and API policies before publishing.


## Horizon OS overlay mode (v0.2.0)

The Android manifest additions are in `src/android/`:

- `extra_manifest.xml` declares the Meta Horizon OS SDK target.
- `extra_manifest_application.xml` declares Quest 2/3/3S support and an
  `activity-alias` with `com.oculus.intent.category.2D` and
  `com.oculus.intent.category.OVERLAY_LAUNCHER`.

On a compatible headset/software version, launch an immersive app, open the
Horizon OS universal menu/overlay launcher, and select QUEST LIVE HUB. The OS
should launch the app as a 2D panel over the immersive app. The user initiates
this action; the app does not force itself over other apps.

This overlay-launcher route is specific to Meta Horizon OS. It is not a general
Android floating-window permission and is not guaranteed to work over every
system surface or app. `SYSTEM_ALERT_WINDOW` is deliberately absent because
Meta lists it as a prohibited permission for Horizon OS Store submissions.

The existing "WRIST LAYOUT" button only changes the 2D layout density. It does
not physically attach the panel to the user's wrist. A wrist-anchored overlay
needs a native immersive/spatial implementation and is a separate milestone.

### Build

Use a current Buildozer version that supports
`android.extra_manifest_application_xml`:

```bash
python -m pip install --upgrade pip setuptools wheel
python -m pip install git+https://github.com/kivy/buildozer.git
python -m pip install cython==0.29.36
buildozer android debug
```

The APK should appear in `bin/`. The included GitHub Actions workflow builds a
debug APK and uploads it as an artifact. This source archive itself is not an
APK, and the overlay must be tested on a real Quest headset before relying on it.
